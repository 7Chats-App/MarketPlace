﻿using Makert.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Makert
{
    public class RouteConfig
    {
        private static MakertEntities db = new MakertEntities();
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
            var country = RegionInfo.CurrentRegion.DisplayName;
            AccessData accessData = new AccessData()
            {
                Country = country,
                DateCreated = DateTime.Now,

            };
            db.AccessDatas.Add(accessData);
            db.SaveChanges();


        }
    }
}
