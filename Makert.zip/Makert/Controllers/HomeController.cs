﻿using Makert.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Makert.Controllers
{
    public class HomeController : Controller
    {
        SendEmail sendEmail = new SendEmail();
        private MakertEntities db = new MakertEntities();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Final()
        {
            return View();
        }
        public ActionResult Login()
        {
       ;
            return View();
        }
        [HttpPost]
        public JsonResult Login(Login login)
        {
            var account_ = db.AccountDetails.FirstOrDefault(x => x.Email.ToLower() == login.Email.ToLower() && x.Password == login.Password && x.Approved==true);
            if (account_ != null)
            {
                Session["Name"] = account_.FirstName+" "+account_.LastName;
                Session["Expiry"] = DateTime.UtcNow.AddMinutes(20);
                Session["ID"] = account_.Id;
                return Json("successful");
            }
            else
            {
                return Json("User not registered or user is no approved");
            }
        }
        public ActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public JsonResult Registration(AccountDetail accountDetail)
        {
            var account_ = db.AccountDetails.FirstOrDefault(x=>x.Email.ToLower()==accountDetail.Email.ToLower());
            if(account_!=null)
            {
                return Json("account already exist");
            }
            AccountDetail account = new AccountDetail
            {
                Email = accountDetail.Email,
                Approved = false,
                DateCreated = DateTime.Now,
                City = accountDetail.City,
                ContactNumber = accountDetail.ContactNumber,
                FirstName = accountDetail.FirstName,
                LastName = accountDetail.LastName,
                Password = accountDetail.Password,
                State = accountDetail.State,
                CompanyWebsite = accountDetail.CompanyWebsite,
                Company = accountDetail.Company,
                CompanyName = accountDetail.CompanyName
            };
            try
            {
                db.AccountDetails.Add(account);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                return Json("Something went wrong please try again or contact this number");
            }
            return Json("successful");
        }

        [HttpPost]
        public JsonResult Recovery(Recovery  recovery)
        {
            var account_ = db.AccountDetails.FirstOrDefault(x => x.Email.ToLower() == recovery.Email.ToLower() && x.Approved==true);
            if (account_ != null)
            {
                sendEmail.Send(account_.Email,"Your password is "+account_.Password,"Makert Place password recovery");
                //send email
                return Json("successful");
            }
            else
            {
                return Json("User not registered or user is no approved");
            }
        }
    }
}