﻿namespace Makert.Controllers
{
    public class Recovery
    {
        public string Email { get; set; }
    }
}