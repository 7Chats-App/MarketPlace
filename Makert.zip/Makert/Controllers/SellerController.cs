﻿using Makert.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace Makert.Controllers
{
    public class SellerController : Controller
    {
        private MakertEntities db = new MakertEntities();
        // GET: Seller
        public ActionResult Index()
        {
            if (Session["Expiry"] != null)
            {
                var id = Session["ID"].ToString();
                var ID = int.Parse(id);
                var ads = db.Ads.Include(a => a.Category).Include(a => a.Location).Where(x=>x.UserID== ID);
                return View(ads.ToList());
            }
            else
            {
                return RedirectToAction("Login","Home");
            }
            
        }
        public ActionResult Create()
        {
            if (Session["Expiry"] != null)
            {
                ViewBag.CategoryID = new SelectList(db.Categories, "Id", "Category1");
                ViewBag.LocationID = new SelectList(db.Locations, "Id", "Location1");
                return View();
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
          
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CategoryID,LocationID,Subject,Description,isActive,DateCreated")] Ad ad)
        {
            var id = Session["ID"].ToString();
            var ID = int.Parse(id);
            ad.isActive = true;
            ad.DateCreated = DateTime.Now;
            ad.UserID = ID;
            if (ModelState.IsValid)
            {
                db.Ads.Add(ad);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryID = new SelectList(db.Categories, "Id", "Category1", ad.CategoryID);
            ViewBag.LocationID = new SelectList(db.Locations, "Id", "Location1", ad.LocationID);
            return View(ad);
        }
    }
}