﻿using Makert.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Makert.Controllers
{
    public class AdminController : Controller
    {
        private MakertEntities db = new MakertEntities();
        // GET: Admin
        public ActionResult Index()
        {
            States state = new States()
            {
                TotalVisitors = db.AccessDatas.Count(),
                ApprovedSellers = db.AccountDetails.Where(x => x.Approved == true && x.FirstName != "Admin").Count(),
                PendingApproval = db.AccountDetails.Where(x => x.Approved == false && x.FirstName != "Admin").Count(),
                Ads = db.Ads.ToList().Count()
            };

            if (Session["Admin"] != null)
            {
                return View(state);
            }
            else
            {
                return RedirectToAction("Login", "Admin");
            }
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public JsonResult Login(Login login)
        {
            var account_ = db.AccountDetails.FirstOrDefault(x => x.Email.ToLower() == login.Email.ToLower() && x.Password == login.Password && (x.FirstName + " " + x.LastName).ToLower().Contains("admin"));
            if (account_ != null)
            {
                Session["Admin"] = account_.FirstName + " " + account_.LastName;
                Session["Expiry"] = DateTime.UtcNow.AddMinutes(20);
                return Json("successful");
            }
            else
            {
                return Json("User not registered or user is no approved");
            }
        }
        public ActionResult SellersApprover()
        {
            if (Session["Admin"] != null)
            {
                return View(db.AccountDetails.Where(x => x.Approved == false && x.Company==true && x.FirstName.ToLower() != "admin").ToList());
            }
            else
            {
                return RedirectToAction("Login", "Admin");
            }

        }
        public ActionResult SellersindividualApprover()
        {
            if (Session["Admin"] != null)
            {
                return View(db.AccountDetails.Where(x => x.Approved == false && x.Company == false && x.FirstName.ToLower()!="admin").ToList());
            }
            else
            {
                return RedirectToAction("Login", "Admin");
            }

        }
        public ActionResult AllSellers()
        {
            if (Session["Admin"] != null)
            {
                return View(db.AccountDetails.Where(x => x.Approved == true && x.FirstName.ToLower() != "admin").ToList());
            }
            else
            {
                return RedirectToAction("Login", "Admin");
            }
        }
        public ActionResult EditSeller(int? id)
        {
            if (Session["Admin"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                AccountDetail accountDetail = db.AccountDetails.Find(id);
                if (accountDetail == null)
                {
                    return HttpNotFound();
                }
                return View(accountDetail);
            }
            else
            {
                return RedirectToAction("Login", "Admin");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditSeller([Bind(Include = "Id,Email,Password,FirstName,LastName,ContactNumber,State,City,DateCreated,Approved")] AccountDetail accountDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(accountDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("SellersApprover");
            }
            return View(accountDetail);
        }
        [HttpPost]
        public JsonResult PushData(string[] array)
        {
            try
            {
                foreach(var s in array)
                {
                    var account_ = db.AccountDetails.FirstOrDefault(x => x.Id.ToString()==s);
                    if (account_ != null)
                    {
                        account_.Approved = true;
                        db.Entry(account_).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                }
                return Json("successful");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }
        [HttpPost]
        public JsonResult PushDatas(string[] array)
        {
            try
            {
                foreach (var s in array)
                {
                    var account_ = db.AccountDetails.FirstOrDefault(x => x.Id.ToString() == s);
                    if (account_ != null)
                    {
                        account_.Approved = true;
                        db.Entry(account_).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                }
                return Json("successful");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }
        [HttpPost]
        public JsonResult PushDatasSave(string[] array)
        {
            try
            {
                foreach (var s in array)
                {
                    var account_ = db.AccountDetails.FirstOrDefault(x => x.Id.ToString() == s);
                    if (account_ != null)
                    {
                        account_.Approved = false;
                        db.Entry(account_).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                }
                return Json("successful");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }
    }
}