﻿namespace Makert.Controllers
{
    public class States
    {
        public int PendingApproval { get; set; }
        public int ApprovedSellers { get; set; }
        public int TotalVisitors { get; set; }
        public int Ads { get; set; }
    }
}