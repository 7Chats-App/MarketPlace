﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;

namespace Makert.Controllers
{
    public class SendEmail
    {
        public void Send(string to,string body,string subject)
        {
            try
            {
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);

                smtpClient.Credentials = new System.Net.NetworkCredential("techafricasolutions@gmail.com", "Asimbonge@6");
                smtpClient.UseDefaultCredentials = false; // uncomment if you don't want to use the network credentials
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.EnableSsl = true;

                MailMessage mail = new MailMessage();

                //Setting From , To and CC
                mail.From = new MailAddress("techafricasolutions@gmail.com", "Makert Place");
                mail.To.Add(new MailAddress(to));
                mail.Subject = subject;
                mail.Body = body;

                smtpClient.Send(mail);
            }
            catch (Exception ex)
            {

            }
          
        }
    }
}
